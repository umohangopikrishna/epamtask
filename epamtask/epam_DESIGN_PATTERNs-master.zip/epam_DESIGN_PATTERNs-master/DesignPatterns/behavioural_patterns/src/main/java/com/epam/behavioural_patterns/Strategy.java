package com.epam.behavioural_patterns;

public interface Strategy {
    public float calculation(float a, float b);

}
