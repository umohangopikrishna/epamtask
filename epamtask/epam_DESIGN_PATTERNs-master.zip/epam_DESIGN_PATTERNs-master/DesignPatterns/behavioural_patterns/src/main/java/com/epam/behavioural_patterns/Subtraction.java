package com.epam.behavioural_patterns;

public class Subtraction implements Strategy{
    //@Override
	public float calculation(float a, float b) {
		return a - b;
	} 

}
