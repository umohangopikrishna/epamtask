package com.epam.creational_patterns;

public class CommercialPlan extends Plan{
    public void getRate() {
		rate = 12.75;
	}

}
