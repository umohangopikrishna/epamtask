package com.epam.creational_patterns;

public class DomesticPlan extends Plan{
    public void getRate() {
		rate = 5.50;
	}

}
