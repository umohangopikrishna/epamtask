package com.epam.creational_patterns;

public interface Prototype {
    public Prototype getClone();

}
